# 📂 Restrict Removable Device (Windows Group Policy)

This repository documents a practical approach to **prohibit removable storage device access** on Windows,
while **allowing only specific whitelisted devices (by Hardware ID)**. It also covers basic user-rights
hardening for Standard users.

> Target OS: Windows 10/11 Pro/Enterprise (Local Group Policy)  
> Context: Small/medium environments without central AD GPOs

---

## 🧭 Overview
- Deny all removable storage devices (USB mass storage, portable HDDs, etc.).
- Allow installation/usage of **only** the explicitly permitted device IDs.
- Block **CD/DVD** read/write/execute access.
- Harden Standard User privileges (avoid local admin where unnecessary).

---

## ✅ Prerequisites
- You have access to a local **Administrator** account.
- Target machines are Windows 10/11 with **gpedit.msc** available.
- You have the **Hardware ID(s)** of the allowed/whitelisted device(s).

---

## 🛠 Step-by-step Implementation

### 1) Prepare Accounts & Rights
- Enable/ensure an **Administrator** account for configuration.
- Move the day-to-day user to **Standard User**, and (if required) grant only limited groups like:
  - **Power Users**
  - **Network Configuration Operators**
- Change default admin password and store it securely.

### 2) Configure Device Installation Restrictions (Local GPO)
1. Open **gpedit.msc** → **Computer Configuration** → **Administrative Templates** → **System** → **Device Installation** → **Device Installation Restrictions**.
2. **Allow installation of devices that match any of these device IDs** → *Enabled* → **Show** → paste the Hardware ID(s) of the device(s) you allow.
   - Find Hardware ID: open **devmgmt.msc** → device **Properties** → **Details** tab → **Hardware Ids** → copy the most specific top entry.
3. **Prevent installation of devices not described by other policy settings** → *Enabled*.

### 3) Deny CD/DVD Access
- **gpedit.msc** → **Computer Configuration** → **Administrative Templates** → **System** → **Removable Storage Access**:
  - Set **CD and DVD: Deny read access** → *Enabled*
  - Set **CD and DVD: Deny write access** → *Enabled*
  - (Optional) **All Removable Storage classes: Deny all access** for stricter posture.

### 4) Apply & Reboot
- Run:
  ```bat
  gpupdate /force
  ```
- **Restart** the machine and validate behavior.

### 5) Validation Checklist
- Non-whitelisted USB storage fails to install/use.
- Whitelisted device (matching your Hardware ID) installs/works.
- CD/DVD media cannot be read or written.
- Standard user cannot elevate/override policies.

---

## 🧪 How to Collect a Hardware ID (Whitelist)
1. Plug in the device you want to allow.
2. Open **Device Manager** (`devmgmt.msc`).
3. Right-click the device → **Properties** → **Details** → **Property: Hardware Ids**.
4. Copy the **first (most specific)** value and paste into the policy’s **Show** list.

> Tip: Keep a small text file of approved IDs under `docs/allowed-hardware-ids.txt` for auditability.

---

## 🧷 Repository Structure
```
restrict-removable-device-project/
├─ README.md                   # This guide
├─ LICENSE                     # MIT License
├─ .gitignore                  # Ignore temp/editor files
└─ docs/
   └─ restrict-removable-device.pdf  # Original project document (from author)
```

---

## 🐞 Troubleshooting
- **Policy not applying?** Run `gpresult /h report.html` to verify Computer policies applied.
- **Device still installs?** Double-check you added the **correct** Hardware ID and enabled
  “Prevent installation of devices not described by other policy settings”.
- **Standard user can still plug new devices?** Ensure the GPO is applied at **Computer Configuration**,
  and that the user isn’t Local Admin.

---

## 🔐 Security Notes
- Never publish internal IPs/passwords in screenshots or documents.
- Consider BitLocker and Attack Surface Reduction (ASR) rules for broader device control.

---

## 📄 Credits
Authored by **Shahin**. Original planning document included under `docs/`.
